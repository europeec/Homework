//
//  Data.swift
//  GraphView
//
//  Created by Дмитрий Юдин on 18.05.2021.
//

import Foundation

let data = [[Graph(description: "hello")], [Graph(description: "Hello"), Graph(description: "world"), Graph(description: "Hello"), Graph(description: "world")], [Graph(description: "Hello"), Graph(description: "world")], [Graph(description: "Hello"), Graph(description: "world"), Graph(description: "Hello")], [Graph(description: "Hello"), Graph(description: "world")]]
